var a = require('a');

t.equal(a, 'good');
