var foo = require('./foo');
var foodup = require('./foo-dup');

foo();
foodup();
