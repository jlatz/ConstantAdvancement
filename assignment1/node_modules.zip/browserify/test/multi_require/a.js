module.exports = function() {
  return 'a';
}
