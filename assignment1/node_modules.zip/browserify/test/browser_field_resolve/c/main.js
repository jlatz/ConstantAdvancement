console.log(require('./z.js'))
