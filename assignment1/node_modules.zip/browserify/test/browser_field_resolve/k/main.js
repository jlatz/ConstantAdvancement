var zzz = require('x/zzz')
console.log(zzz)
