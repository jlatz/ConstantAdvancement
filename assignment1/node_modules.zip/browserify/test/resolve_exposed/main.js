var xyz = require('xyz');
console.log(xyz * 111);
