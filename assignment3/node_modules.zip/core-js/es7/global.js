require('../modules/es7.global');
module.exports = require('../modules/_core').global;
