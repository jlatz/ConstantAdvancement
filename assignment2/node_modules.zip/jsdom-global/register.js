require('./index')()
